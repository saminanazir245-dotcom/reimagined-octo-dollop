import { Type } from "@google/genai";

export enum WorkflowStage {
  NICHE_IDEAS = 1,
  VARIATIONS = 2,
  UPSCALE_PREP = 3,
  MOCKUPS = 4,
  SEO_LISTING = 5
}

export interface WallArtIdea {
  id: string;
  title: string;
  style: string;
  palette: string[];
  targetBuyer: string;
  bestFor: string;
  whySells: string;
}

export interface Variation {
  id: string;
  styleDirection: string;
  mood: string;
  palette: string[];
  composition: string;
  typography: string;
  texture: string;
  aiPrompt: string;
}

export interface PrepInfo {
  finalPrompt: string;
  negativePrompt: string;
  dimensions: string[];
  exportRecs: string[];
  upscaling: string;
  cleanup: string;
  optimization: string;
}

export interface Mockup {
  id: string;
  scene: string;
  interiorStyle: string;
  lighting: string;
  frame: string;
  prompt: string;
}

export interface SEOListing {
  title: string;
  description: string;
  tags: string[];
  materials: string[];
  altText: string;
  socialCaption: string;
}

export const IDEA_GENERATION_SCHEMA = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      title: { type: Type.STRING },
      style: { type: Type.STRING },
      palette: { type: Type.ARRAY, items: { type: Type.STRING } },
      targetBuyer: { type: Type.STRING },
      bestFor: { type: Type.STRING },
      whySells: { type: Type.STRING },
    },
    required: ["id", "title", "style", "palette", "targetBuyer", "bestFor", "whySells"]
  }
};

export const VARIATION_GENERATION_SCHEMA = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      styleDirection: { type: Type.STRING },
      mood: { type: Type.STRING },
      palette: { type: Type.ARRAY, items: { type: Type.STRING } },
      composition: { type: Type.STRING },
      typography: { type: Type.STRING },
      texture: { type: Type.STRING },
      aiPrompt: { type: Type.STRING },
    },
    required: ["id", "styleDirection", "mood", "palette", "composition", "typography", "texture", "aiPrompt"]
  }
};
