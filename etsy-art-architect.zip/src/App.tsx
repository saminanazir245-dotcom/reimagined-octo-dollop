import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  ChevronRight, 
  Image as ImageIcon, 
  Settings, 
  Layers, 
  Search, 
  Copy, 
  CheckCircle2, 
  ArrowLeft,
  Loader2,
  Trash2
} from "lucide-react";
import { geminiService } from "./services/geminiService";
import { 
  WorkflowStage, 
  WallArtIdea, 
  Variation, 
  PrepInfo, 
  Mockup, 
  SEOListing 
} from "./types";

export default function App() {
  const [stage, setStage] = useState<WorkflowStage>(WorkflowStage.NICHE_IDEAS);
  const [theme, setTheme] = useState("");
  const [loading, setLoading] = useState(false);
  const [ideas, setIdeas] = useState<WallArtIdea[]>([]);
  const [selectedIdea, setSelectedIdea] = useState<WallArtIdea | null>(null);
  const [variations, setVariations] = useState<Variation[]>([]);
  const [selectedVariation, setSelectedVariation] = useState<Variation | null>(null);
  const [prepInfo, setPrepInfo] = useState<PrepInfo | null>(null);
  const [mockups, setMockups] = useState<Mockup[]>([]);
  const [seo, setSeo] = useState<SEOListing | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const handleGenerateIdeas = async () => {
    if (!theme) return;
    setLoading(true);
    try {
      const result = await geminiService.generateNicheIdeas(theme);
      setIdeas(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectIdea = async (idea: WallArtIdea) => {
    setSelectedIdea(idea);
    setLoading(true);
    try {
      const result = await geminiService.generateVariations(idea);
      setVariations(result);
      setStage(WorkflowStage.VARIATIONS);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectVariation = async (variation: Variation) => {
    setSelectedVariation(variation);
    setLoading(true);
    try {
      const [prep, mock, seoRes] = await Promise.all([
        geminiService.generatePrepInfo(variation),
        geminiService.generateMockups(variation),
        geminiService.generateSEO(variation, selectedIdea!)
      ]);
      setPrepInfo(prep);
      setMockups(mock);
      setSeo(seoRes);
      setStage(WorkflowStage.UPSCALE_PREP);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const resetAll = () => {
    setStage(WorkflowStage.NICHE_IDEAS);
    setTheme("");
    setIdeas([]);
    setSelectedIdea(null);
    setVariations([]);
    setSelectedVariation(null);
    setPrepInfo(null);
    setMockups([]);
    setSeo(null);
  };

  return (
    <div className="h-screen w-full flex overflow-hidden bg-sleek-bg transition-colors duration-500">
      {/* Sidebar Navigation */}
      <aside className="w-72 bg-sleek-dark text-white flex flex-col h-full z-50">
        <div className="p-10">
          <div className="text-[10px] tracking-[0.3em] text-sleek-accent uppercase font-bold mb-1 opacity-80">Studio AI</div>
          <div className="text-2xl font-light italic font-serif">Etsy Curator</div>
        </div>
        
        <nav className="flex-1 px-6 space-y-3 mt-4">
          {[
            { s: WorkflowStage.NICHE_IDEAS, label: "Niche IDEATION", id: "01" },
            { s: WorkflowStage.VARIATIONS, label: "Visual VARIATIONS", id: "02" },
            { s: WorkflowStage.UPSCALE_PREP, label: "UPSCALING & PREP", id: "03" },
          ].map(({ s, label, id }) => (
            <div 
              key={s}
              onClick={() => stage >= s && setStage(s)}
              className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-300 group cursor-pointer ${
                stage === s 
                  ? "bg-sleek-accent text-white shadow-xl shadow-black/20 translate-x-2" 
                  : stage > s 
                    ? "text-white/60 hover:bg-white/5 hover:text-white" 
                    : "text-white/20 cursor-not-allowed"
              }`}
            >
              <div className={`w-6 h-6 flex items-center justify-center border rounded text-[9px] font-mono transition-colors ${
                stage === s ? "border-white/40" : "border-white/10 group-hover:border-white/30"
              }`}>{id}</div>
              <span className={`text-xs font-semibold uppercase tracking-widest ${stage === s ? "opacity-100" : "opacity-70 group-hover:opacity-100"}`}>
                {label}
              </span>
            </div>
          ))}
        </nav>

        <div className="p-8 border-t border-white/5">
          <div className="bg-white/5 rounded-2xl p-6 backdrop-blur-sm border border-white/5">
            <div className="text-[9px] text-white/30 uppercase tracking-[0.2em] mb-3 italic">Current Studio Context</div>
            <div className="text-xs font-medium leading-relaxed text-sleek-accent">
              {selectedIdea ? selectedIdea.title : "Awaiting initial niche input..."}
            </div>
            {selectedVariation && (
              <div className="mt-3 text-[10px] text-white/50 border-t border-white/5 pt-3 animate-pulse">
                Refining: {selectedVariation.styleDirection}
              </div>
            )}
          </div>
          <button 
            onClick={resetAll}
            className="w-full mt-6 flex items-center justify-center gap-2 p-3 text-[10px] uppercase tracking-widest font-bold text-red-400/60 hover:text-red-400 hover:bg-red-400/5 transition-all rounded-xl"
          >
            <Trash2 size={14} />
            Reset Session
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <header className="h-24 border-b border-sleek-border flex items-center justify-between px-12 bg-white/50 backdrop-blur-sm shrink-0">
          <div>
            <h1 className="text-2xl font-medium text-sleek-dark">
              {stage === WorkflowStage.NICHE_IDEAS && "Stage 1: Niche Generation"}
              {stage === WorkflowStage.VARIATIONS && "Stage 2: Visual Variations"}
              {stage === WorkflowStage.UPSCALE_PREP && "Stage 3: Production Prep"}
            </h1>
            <p className="text-xs text-sleek-accent mt-1 tracking-tight">
              {loading ? "AI processing requested assets..." : "Finalizing commercial-quality wall art logic."}
            </p>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex -space-x-3">
              <div className="w-10 h-10 rounded-full bg-sleek-bg border-4 border-white shadow-sm"></div>
              <div className="w-10 h-10 rounded-full bg-[#E5E3DF] border-4 border-white shadow-sm"></div>
              <div className="w-10 h-10 rounded-full bg-sleek-accent border-4 border-white shadow-sm"></div>
            </div>
          </div>
        </header>

        {/* Dynamic Content Body */}
        <div className="flex-1 overflow-y-auto bg-sleek-bg/30">
          <div className="max-w-5xl mx-auto p-12">
            <AnimatePresence mode="wait">
              {/* STAGE 1 CONTENT */}
              {stage === WorkflowStage.NICHE_IDEAS && (
                <motion.div
                  key="ideas"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="space-y-12"
                >
                  <div className="max-w-2xl">
                    <p className="text-[11px] uppercase tracking-[0.4em] font-bold text-sleek-accent mb-4">Strategic Ideation</p>
                    <h2 className="text-5xl leading-[1.1] mb-6">Discover untapped <br/><span className="italic font-serif">premium art</span> niches.</h2>
                  </div>

                  <div className="flex gap-0 group shadow-2xl shadow-sleek-accent/10 rounded-full overflow-hidden bg-white border border-sleek-border focus-within:border-sleek-dark transition-all">
                    <div className="pl-8 flex items-center text-sleek-accent/40"><Search size={20} /></div>
                    <input
                      type="text"
                      placeholder="Input niche theme (e.g. Minimalist Abstract Landscapes)..."
                      value={theme}
                      onChange={(e) => setTheme(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleGenerateIdeas()}
                      className="flex-1 px-6 py-6 focus:outline-none text-lg font-light placeholder:text-sleek-muted/30"
                    />
                    <button
                      onClick={handleGenerateIdeas}
                      disabled={loading || !theme}
                      className="bg-sleek-dark text-white px-10 hover:bg-black transition-colors disabled:opacity-50 flex items-center gap-3 font-semibold uppercase tracking-widest text-xs"
                    >
                      {loading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                      Analyze
                    </button>
                  </div>

                  {ideas.length > 0 && (
                    <div className="grid grid-cols-1 gap-6 pt-10">
                      {ideas.map((idea, idx) => (
                        <motion.div
                          key={idea.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className="group relative bg-white border border-sleek-border p-10 rounded-[2.5rem] hover:border-sleek-accent transition-all cursor-pointer hover:shadow-[0_20px_50px_rgba(139,126,102,0.1)] flex gap-10"
                          onClick={() => handleSelectIdea(idea)}
                        >
                          <div className="w-16 shrink-0 flex flex-col items-center">
                            <span className="text-[11px] font-mono opacity-20 mb-4 tracking-tighter">ID:0{idx + 1}</span>
                            <div className="w-px h-full bg-sleek-border group-hover:bg-sleek-accent transition-colors" />
                            <div className="w-3 h-3 rounded-full bg-sleek-accent mt-4 scale-0 group-hover:scale-100 transition-transform" />
                          </div>
                          
                          <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div>
                              <h3 className="text-3xl mb-4 group-hover:text-sleek-accent transition-colors">{idea.title}</h3>
                              <p className="text-sm text-sleek-muted leading-relaxed italic border-l-2 border-sleek-accent/10 pl-4">{idea.whySells}</p>
                            </div>
                            <div className="grid grid-cols-2 gap-4 text-[11px]">
                              <div className="space-y-4">
                                <div>
                                  <span className="opacity-40 uppercase tracking-widest block mb-1">Target Persona</span>
                                  <p className="font-semibold">{idea.targetBuyer}</p>
                                </div>
                                <div className="flex gap-1">
                                  {idea.palette.map(c => <div key={c} className="w-4 h-4 rounded-full border border-black/5" style={{ backgroundColor: c }} />)}
                                </div>
                              </div>
                              <div className="space-y-4">
                                <div>
                                  <span className="opacity-40 uppercase tracking-widest block mb-1">Optimal Locale</span>
                                  <p className="font-semibold">{idea.bestFor}</p>
                                </div>
                                <button className="p-3 bg-sleek-bg rounded-xl opacity-0 group-hover:opacity-100 translate-x-4 group-hover:translate-x-0 transition-all text-sleek-dark">
                                  <ChevronRight size={18} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}

              {/* STAGE 2 CONTENT */}
              {stage === WorkflowStage.VARIATIONS && (
                <motion.div
                  key="variations"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-12"
                >
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-[11px] uppercase tracking-[0.4em] font-bold text-sleek-accent mb-3">Visual Architecture</p>
                      <h2 className="text-5xl leading-tight">Artistic <br/><span className="italic font-serif">Directions.</span></h2>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    {variations.map((v, idx) => (
                      <motion.div
                        key={v.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        onClick={() => handleSelectVariation(v)}
                        className={`group bg-white border-2 p-10 rounded-[3rem] transition-all duration-500 cursor-pointer flex flex-col h-[500px] overflow-hidden ${
                          idx === 0 ? "border-sleek-accent" : "border-sleek-border hover:border-sleek-accent"
                        }`}
                      >
                        <div className="flex justify-between items-start mb-8">
                          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-sleek-accent bg-sleek-bg px-4 py-1.5 rounded-full">
                            Variation #0{idx + 1}
                          </span>
                          <div className="flex gap-1.5">
                            {v.palette.map(c => <div key={c} className="w-3.5 h-3.5 rounded-full border border-black/5" style={{ backgroundColor: c }} />)}
                          </div>
                        </div>

                        <div className="flex-1 bg-sleek-bg/50 rounded-[2rem] border-2 border-dashed border-sleek-border mb-8 flex flex-col items-center justify-center p-8 transition-colors group-hover:bg-sleek-bg">
                           <ImageIcon size={32} className="text-sleek-accent/20 mb-4" />
                           <p className="text-[10px] text-center uppercase tracking-widest text-sleek-muted/60 max-w-[200px]">
                             Visual Preview: {v.composition} with {v.texture}
                           </p>
                        </div>

                        <div className="space-y-4">
                          <h4 className="text-2xl font-serif">{v.styleDirection}</h4>
                          <p className="text-[11px] text-sleek-muted leading-relaxed line-clamp-2 italic opacity-60 group-hover:opacity-100 transition-opacity">
                            "{v.aiPrompt}"
                          </p>
                          <div className="flex items-center justify-between pt-4 border-t border-sleek-border">
                            <span className="text-[10px] font-bold uppercase tracking-widest text-sleek-accent">{v.mood}</span>
                            <span className="text-[10px] uppercase font-bold opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">Select Engine →</span>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* STAGE 3-5 CONTENT */}
              {stage === WorkflowStage.UPSCALE_PREP && (
                <motion.div
                  key="prep"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-16"
                >
                  <div className="flex items-center gap-10">
                    <div className="flex-1">
                      <p className="text-[11px] uppercase tracking-[0.4em] font-bold text-sleek-accent mb-3">Generation Engine & SEO</p>
                      <h2 className="text-5xl leading-tight font-serif italic text-sleek-dark underline decoration-sleek-accent underline-offset-[12px]">{selectedVariation?.styleDirection}</h2>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    <div className="space-y-10">
                      <div className="bg-sleek-dark text-white p-12 rounded-[3.5rem] shadow-2xl shadow-black/30 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-sleek-accent/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-1000" />
                        <div className="flex items-center gap-4 mb-8">
                          <div className="p-3 bg-white/10 rounded-2xl border border-white/5 shadow-inner"><Sparkles size={22} className="text-sleek-accent" /></div>
                          <h3 className="text-2xl font-medium tracking-tight">Master Asset Prompt</h3>
                        </div>
                        <div className="space-y-6">
                          <div className="relative">
                            <div className="text-sm font-light text-white/90 bg-white/5 p-8 rounded-3xl leading-relaxed border border-white/10 italic font-mono selection:bg-sleek-accent">
                              {prepInfo?.finalPrompt}
                            </div>
                            <button 
                              onClick={() => copyToClipboard(prepInfo?.finalPrompt || "", "master")}
                              className="absolute -top-4 -right-4 p-4 bg-sleek-accent text-white rounded-2xl shadow-xl hover:scale-110 active:scale-95 transition-all outline-none"
                            >
                              {copied === "master" ? <CheckCircle2 size={20} /> : <Copy size={20} />}
                            </button>
                          </div>
                          <div className="px-4">
                             <p className="text-[9px] uppercase tracking-[0.3em] text-white/30 font-bold mb-2 italic">Negative Parameters</p>
                             <p className="text-[10px] font-mono text-white/40 leading-snug">{prepInfo?.negativePrompt}</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white p-10 rounded-[3rem] border-2 border-sleek-border space-y-8">
                        <div className="flex items-center gap-4">
                          <div className="p-3 bg-sleek-bg rounded-2xl"><Settings size={22} className="text-sleek-accent" /></div>
                          <h3 className="text-2xl font-medium">Export Protocol</h3>
                        </div>
                        <div className="grid grid-cols-2 gap-6">
                           <div className="aspect-square bg-sleek-bg rounded-[2.5rem] flex flex-col items-center justify-center gap-3 p-6 text-center border-l-4 border-sleek-accent">
                              <ImageIcon className="text-sleek-accent/40" size={24} />
                              <span className="text-[10px] uppercase font-bold tracking-widest opacity-40">300 DPI Format</span>
                              <span className="text-xs font-semibold">{prepInfo?.exportRecs[0] || "JPG / PNG (RGB)"}</span>
                           </div>
                           <div className="aspect-square bg-sleek-bg rounded-[2.5rem] flex flex-col items-center justify-center gap-3 p-6 text-center border-l-4 border-sleek-accent">
                              <Layers className="text-sleek-accent/40" size={24} />
                              <span className="text-[10px] uppercase font-bold tracking-widest opacity-40">Standard Ratios</span>
                              <span className="text-xs font-semibold">{prepInfo?.dimensions.slice(0, 2).join(" • ")}</span>
                           </div>
                        </div>
                        <div className="space-y-4 pt-4">
                          <p className="text-xs leading-relaxed"><span className="text-sleek-accent uppercase tracking-widest font-bold block mb-1">Quality Control:</span> {prepInfo?.optimization}</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white p-12 rounded-[4rem] border border-sleek-border flex flex-col shadow-sm">
                      <div className="flex items-center gap-4 mb-10">
                        <div className="p-3 bg-sleek-bg rounded-2xl"><ImageIcon size={22} className="text-sleek-accent" /></div>
                        <h3 className="text-2xl font-medium">Professional Mockups</h3>
                      </div>
                      <div className="flex-1 space-y-6">
                        {mockups.map((m, idx) => (
                          <div key={m.id} className="group border-b border-sleek-border pb-6 last:border-0 hover:border-sleek-accent transition-colors">
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <span className="text-[10px] font-black uppercase text-sleek-accent tracking-widest block mb-1">MOCKUP #0{idx+1}</span>
                                <h5 className="text-lg font-serif italic text-sleek-dark group-hover:text-sleek-accent transition-colors">{m.scene}</h5>
                              </div>
                              <button 
                                onClick={() => copyToClipboard(m.prompt, m.id)}
                                className="px-4 py-2 bg-sleek-bg hover:bg-sleek-dark hover:text-white rounded-full text-[10px] font-bold uppercase tracking-widest transition-all"
                              >
                                {copied === m.id ? "System Copied" : "Copy Prompt"}
                              </button>
                            </div>
                            <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] opacity-50 uppercase tracking-tighter">
                              <span>Style: {m.interiorStyle}</span>
                              <span>•</span>
                              <span>Light: {m.lighting}</span>
                              <span>•</span>
                              <span>Framing: {m.frame}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {seo && (
                    <div className="bg-white rounded-[4rem] border-2 border-sleek-border overflow-hidden shadow-2xl shadow-sleek-accent/5">
                      <div className="bg-sleek-dark p-16 text-center border-b border-white/5">
                        <div className="text-sleek-accent text-[10px] font-black uppercase tracking-[0.6em] mb-6">Marketing & Conversion</div>
                        <h3 className="text-6xl text-white font-serif mb-6 leading-none">Etsy Listing <br/><span className="italic opacity-60">Optimized.</span></h3>
                        <p className="text-white/40 text-sm max-w-lg mx-auto font-light leading-relaxed">Generated with high-yield search intent focused on wall art keywords and emotional visual storytelling.</p>
                      </div>
                      
                      <div className="p-16 grid grid-cols-1 lg:grid-cols-3 gap-20">
                        <div className="lg:col-span-2 space-y-12">
                          <div className="group relative">
                            <label className="text-[10px] font-black uppercase tracking-widest text-sleek-accent mb-4 block">SEO Master Title</label>
                            <div className="text-2xl font-light leading-snug p-10 bg-sleek-bg/50 rounded-[3rem] border border-sleek-border group-hover:border-sleek-accent transition-colors">
                              {seo.title}
                            </div>
                            <button onClick={() => copyToClipboard(seo.title, "title")} className="absolute top-8 right-8 p-3 bg-white text-sleek-dark rounded-2xl shadow-lg border border-sleek-border hover:scale-110 transition-transform"><Copy size={18} /></button>
                          </div>
                          <div className="group relative">
                            <label className="text-[10px] font-black uppercase tracking-widest text-sleek-accent mb-4 block">Description Narrative</label>
                            <div className="whitespace-pre-wrap text-sm leading-[1.8] font-light p-10 bg-sleek-bg/50 rounded-[3rem] border border-sleek-border group-hover:border-sleek-accent transition-colors max-h-[500px] overflow-y-auto custom-scrollbar">
                              {seo.description}
                            </div>
                            <button onClick={() => copyToClipboard(seo.description, "desc")} className="absolute top-8 right-8 p-3 bg-white text-sleek-dark rounded-2xl shadow-lg border border-sleek-border hover:scale-110 transition-transform"><Copy size={18} /></button>
                          </div>
                        </div>

                        <div className="space-y-12 shrink-0">
                          <div className="bg-sleek-bg/50 p-10 rounded-[3rem] border border-sleek-border">
                            <label className="text-[10px] font-black uppercase tracking-widest text-sleek-accent mb-6 block border-b border-sleek-accent/10 pb-4">Keywords (13 Tags)</label>
                            <div className="flex flex-wrap gap-3">
                              {seo.tags.map(t => <span key={t} className="px-4 py-1.5 bg-sleek-dark text-white text-[10px] font-bold uppercase tracking-widest rounded-full">{t}</span>)}
                            </div>
                          </div>
                          
                          <div className="space-y-8 px-6">
                            <div>
                               <label className="text-[10px] font-black uppercase tracking-widest text-sleek-accent mb-2 block">Accessibility Alt-Text</label>
                               <p className="text-xs italic text-sleek-muted/60">{seo.altText}</p>
                            </div>
                            <div className="p-8 bg-sleek-accent/5 rounded-[2.5rem] border border-sleek-accent/10">
                               <label className="text-[10px] font-black uppercase tracking-widest text-sleek-accent mb-4 block">Social Media Hook</label>
                               <p className="text-xs leading-relaxed font-medium italic">"{seo.socialCaption}"</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Footer Navigation Bar */}
        {(stage === WorkflowStage.NICHE_IDEAS && ideas.length > 0) || (stage === WorkflowStage.VARIATIONS) || (stage === WorkflowStage.UPSCALE_PREP) ? (
          <footer className="h-20 border-t border-sleek-border bg-white flex items-center justify-between px-12 shrink-0">
            <p className="text-[10px] text-sleek-accent font-black uppercase tracking-widest">Architectural Session v1.0 • {theme || "Waiting for Niche context"}</p>
            <div className="flex items-center gap-8">
              {stage > WorkflowStage.NICHE_IDEAS && (
                <button 
                  onClick={() => setStage(stage - 1)}
                  className="text-[11px] font-black uppercase tracking-widest text-sleek-muted hover:text-sleek-dark transition-colors"
                >
                  Previous Phase
                </button>
              )}
              {stage < WorkflowStage.UPSCALE_PREP && (
                <div className="text-[10px] text-sleek-accent italic font-serif">Select an asset to advance →</div>
              )}
            </div>
          </footer>
        ) : null}
      </main>

      {/* Global Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 bg-sleek-bg/80 backdrop-blur-md z-[200] flex flex-col items-center justify-center gap-8 animate-in fade-in duration-500">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-4 border-sleek-accent/10 border-t-sleek-dark animate-spin" />
            <Sparkles className="absolute inset-0 m-auto text-sleek-accent animate-pulse" size={32} />
          </div>
          <div className="text-center space-y-2">
            <p className="font-serif italic text-3xl text-sleek-dark tracking-wide">Synthesizing Architecture...</p>
            <p className="text-[10px] uppercase font-black tracking-[0.5em] text-sleek-accent opacity-60">Intelligence in progress</p>
          </div>
        </div>
      )}
    </div>
  );
}

