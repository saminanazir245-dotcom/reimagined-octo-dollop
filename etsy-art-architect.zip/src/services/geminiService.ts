import { GoogleGenAI, Type } from "@google/genai";
import { 
  IDEA_GENERATION_SCHEMA, 
  VARIATION_GENERATION_SCHEMA,
  WallArtIdea,
  Variation,
  PrepInfo,
  Mockup,
  SEOListing
} from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const geminiService = {
  async generateNicheIdeas(theme: string): Promise<WallArtIdea[]> {
    const prompt = `You are an expert Etsy Wall Art AI Assistant. 
    Theme: ${theme}
    Generate 10 HIGH-POTENTIAL Etsy wall art ideas focused on trends, emotional triggers, and aesthetic appeal.
    Avoid overused generic ideas. 
    Focus on minimalist luxury, modern home decor, earth tones, and sophisticated compositions.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: IDEA_GENERATION_SCHEMA
      }
    });

    return JSON.parse(response.text || "[]");
  },

  async generateVariations(idea: WallArtIdea): Promise<Variation[]> {
    const prompt = `You are an expert Etsy Wall Art AI Assistant.
    Selected Idea: ${idea.title} - ${idea.whySells}
    Generate 4 UNIQUE visual variations for this idea.
    Each variation must feel commercially different while remaining within the same family.
    Prompts must be highly descriptive, professional, and optimized for AI generation.
    Always include terms: ultra detailed, high resolution, printable wall art, premium aesthetic, elegant composition, professional lighting, luxury interior styling.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: VARIATION_GENERATION_SCHEMA
      }
    });

    return JSON.parse(response.text || "[]");
  },

  async generatePrepInfo(variation: Variation): Promise<PrepInfo> {
    const prompt = `You are an expert Etsy Wall Art AI Assistant.
    Selected Variation: ${variation.styleDirection} - ${variation.mood}
    Target Prompt: ${variation.aiPrompt}
    
    Generate:
    1. Final enhanced production prompt for highest quality output.
    2. Recommended dimensions (2:3, 3:4, 4:5, 11x14, ISO A).
    3. Etsy-ready export recommendations (PNG, JPG, 300 DPI, RGB).
    4. Upscaling recommendations.
    5. Background cleanup recommendations.
    6. Print quality optimization instructions.
    
    Also provide a NEGATIVE PROMPT avoiding artifacts, watermark, blurry, distorted text, etc.
    
    Return as JSON matching:
    {
      "finalPrompt": "...",
      "negativePrompt": "...",
      "dimensions": ["..."],
      "exportRecs": ["..."],
      "upscaling": "...",
      "cleanup": "...",
      "optimization": "..."
    }`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            finalPrompt: { type: Type.STRING },
            negativePrompt: { type: Type.STRING },
            dimensions: { type: Type.ARRAY, items: { type: Type.STRING } },
            exportRecs: { type: Type.ARRAY, items: { type: Type.STRING } },
            upscaling: { type: Type.STRING },
            cleanup: { type: Type.STRING },
            optimization: { type: Type.STRING }
          },
          required: ["finalPrompt", "negativePrompt", "dimensions", "exportRecs", "upscaling", "cleanup", "optimization"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  },

  async generateMockups(variation: Variation): Promise<Mockup[]> {
    const prompt = `Generate 5 realistic mockup scene ideas for the artwork: ${variation.styleDirection}.
    Each mockup should match the style and include room type, furniture, lighting, wall color, frame style, and decor mood.
    Include a specific AI prompt for rendering the mockup.
    
    Return as JSON matching:
    {
      "mockups": [
        {
          "id": "...",
          "scene": "...",
          "interiorStyle": "...",
          "lighting": "...",
          "frame": "...",
          "prompt": "..."
        }
      ]
    }`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mockups: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  scene: { type: Type.STRING },
                  interiorStyle: { type: Type.STRING },
                  lighting: { type: Type.STRING },
                  frame: { type: Type.STRING },
                  prompt: { type: Type.STRING }
                },
                required: ["id", "scene", "interiorStyle", "lighting", "frame", "prompt"]
              }
            }
          },
          required: ["mockups"]
        }
      }
    });

    return JSON.parse(response.text || '{"mockups": []}').mockups;
  },

  async generateSEO(variation: Variation, idea: WallArtIdea): Promise<SEOListing> {
    const prompt = `Generate Etsy SEO optimized listing for: ${idea.title} - ${variation.styleDirection}.
    Include:
    1. Title (max 140 chars, keyword rich).
    2. Description with emotional hook, download details, printing recommendations.
    3. 13 tags.
    4. Materials section.
    5. Alt text for images.
    6. Short social media caption.
    
    Return as JSON matching:
    {
      "title": "...",
      "description": "...",
      "tags": ["..."],
      "materials": ["..."],
      "altText": "...",
      "socialCaption": "..."
    }`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            materials: { type: Type.ARRAY, items: { type: Type.STRING } },
            altText: { type: Type.STRING },
            socialCaption: { type: Type.STRING }
          },
          required: ["title", "description", "tags", "materials", "altText", "socialCaption"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  }
};
